package base;

import java.io.IOException;

public class Learnfinally {

	public static void main(String[] args) throws IOException {
		int x=10;
		int y=0;
		String s=null;
		try {
			System.out.println(x/y);
		} catch(Exception e){
				System.out.println(e);	
		}finally {
			System.out.println("End of the program");
			Runtime.getRuntime().exec("taskkill /f /im /chromedriver.exe");
	
		}

	}

}
