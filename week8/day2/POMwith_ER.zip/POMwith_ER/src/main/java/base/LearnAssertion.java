package base;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.asserts.SoftAssert;

public class LearnAssertion {

	public static void main(String[] args) {
		ChromeOptions opt = new ChromeOptions();
		opt.addArguments("--disable-notifications");
		ChromeDriver driver = new ChromeDriver(opt);
		driver.get("https://login.salesforce.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.id("username")).sendKeys("hari.radhakrishnan@qeagle.com");
		driver.findElement(By.id("password")).sendKeys("Leaf@1234");
		// click on login button
		driver.findElement(By.id("Login")).click();
		String ExpectedTitle="Home | SalesForce";
		String acttitle = driver.getTitle();
		//Assertion
		//Hard Assert and Soft Assert
		
		//Assert.assertEquals(acttitle, ExpectedTitle);
		SoftAssert soft=new SoftAssert();
		soft.assertEquals(acttitle, ExpectedTitle);
		soft.assertAll();
		System.out.println("Landed in the rightPage");
		
	}

}
