package base;

public class LearnRandom {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double random = Math.random();
		System.out.println(random);
		
		
		int r=(int)(Math.random()*999999);
		System.out.println(r);
		
		
		//411.4546
		//411
	}

}
