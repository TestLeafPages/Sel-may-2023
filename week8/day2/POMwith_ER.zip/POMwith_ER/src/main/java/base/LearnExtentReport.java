package base;

import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class LearnExtentReport {

	public static void main(String[] args) throws IOException {
				
		//Step:1 to create a folder to store the report (html)
		ExtentHtmlReporter reporter =new ExtentHtmlReporter("./reports/result.html");
		//to hold the history of the report
		reporter.setAppendExisting(true);
		//Step:2 to attach the physical reports to the result .html 
		ExtentReports extent =new ExtentReports();		
		extent.attachReporter(reporter);
		
		ExtentTest test = extent.createTest("LoginTc","Login with Positive credentials");
		test.assignAuthor("Silambarasan");
		test.assignCategory("Funtional");
		
		test.pass("Login is successful",MediaEntityBuilder.createScreenCaptureFromPath(".././snap/country.jpg").build());
		test.fail("Login is not successful");		
		
		//mandatory step
		extent.flush();
		
	}

}
