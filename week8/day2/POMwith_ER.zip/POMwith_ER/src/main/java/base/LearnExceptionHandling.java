package base;



public class LearnExceptionHandling {

	public static void main(String[] args) {
		
		int x=10;
		int y=0;
		String s=null;
		try {
			System.out.println(x/y);
		} catch (ArithmeticException e) {
			System.out.println(e);
			System.out.println(s.length());
		}catch(Exception a) {
			System.out.println("check your string value " +a);
		}finally {
		System.out.println("End of the program");
		}
	}

}
