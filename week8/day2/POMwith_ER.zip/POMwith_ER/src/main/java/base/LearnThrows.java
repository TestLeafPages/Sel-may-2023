package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class LearnThrows {
	
	public  void m1() throws InterruptedException {
	
		int x=10;
		int y=15;
	    Thread.sleep(3000);
	    try {
	    	if(x>y) {
	    		System.out.println(x-y);
	    	}else if(x<y) {
	    		throw new Exception("Check your inputs");
	    	}
	    }catch (Exception e) {
			
		}
	    
	    
	
	}
	
	
public static void main(String[] args) throws FileNotFoundException {
	
	FileInputStream fis =new FileInputStream("");
	
}
	
	
	
}
