package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcelData;

public class ProjectSpecificMethod extends AbstractTestNGCucumberTests {

	private static final ThreadLocal<RemoteWebDriver> tlDriver = new ThreadLocal<RemoteWebDriver>();

	public RemoteWebDriver getDriver() {
		return tlDriver.get();
	}

	public void setDriver() {
		tlDriver.set(new ChromeDriver());
	}

	// public static RemoteWebDriver driver;
	public static Properties prop;
	public String filename, shName;
	public static ExtentReports extent;
	public String testName, testDesc, author, category;
	public static ExtentTest test, node;

	@BeforeSuite
	public void startReport() {
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result.html");
		reporter.setAppendExisting(true);
		extent = new ExtentReports();
		extent.attachReporter(reporter);

	}

	@BeforeClass
	public void testCaseDetails() {
		test = extent.createTest(testName, testDesc);
		test.assignAuthor(author);
		test.assignCategory(category);
	}

	public void reportStep(String message, String status) throws Exception {

		if (status.equalsIgnoreCase("pass")) {
			node.pass(message,
					MediaEntityBuilder.createScreenCaptureFromPath(".././snap/shot" + takeSnap() + ".jpg").build());
		} else if (status.equalsIgnoreCase("fail")) {
			node.fail(message,
					MediaEntityBuilder.createScreenCaptureFromPath(".././snap/shot" + takeSnap() + ".jpg").build());
			throw new Exception("Check your Locator");
		}

	}

	public int takeSnap() throws IOException {
		int r = (int) (Math.random() * 999999);
		File screenshotAs = getDriver().getScreenshotAs(OutputType.FILE);
		File destn = new File("./snap/shot" + r + ".jpg");
		FileUtils.copyFile(screenshotAs, destn);
		return r;
	}

	@Parameters({ "language" })
	@BeforeMethod
	public void preCondition(String language) throws IOException {

		node = test.createNode(testName, testDesc);
		setDriver();
		getDriver().manage().window().maximize();

		if (language.equalsIgnoreCase("English")) {
			FileInputStream fis = new FileInputStream("src/main/resources/Config_en.properties");
			prop = new Properties();
			prop.load(fis);
		} else if (language.equalsIgnoreCase("French")) {
			FileInputStream fis = new FileInputStream("src/main/resources/Config_fr.properties");
			prop = new Properties();
			prop.load(fis);
		}
		// driver=new ChromeDriver();

		getDriver().get(prop.getProperty("url"));
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	}

	@AfterMethod
	public void postCondition() {
		getDriver().close();
	}

	@DataProvider()
	public String[][] sendData() throws IOException {

		return ReadExcelData.readData(filename, shName);

	}

	@AfterSuite
	public void endReport() {
		extent.flush();
	}

}
