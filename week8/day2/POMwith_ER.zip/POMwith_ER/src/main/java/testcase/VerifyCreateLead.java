package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;
import pages.WelcomePage;

public class VerifyCreateLead extends ProjectSpecificMethod {

	@BeforeTest
	public void setValues() {
		testName="CreateLead Testcase";
		testDesc="Lead with Mandatory datas";
		author="Jeevitha";
		category="Regression";
		filename ="Leads";
		shName="Sheet1";
	}
	
	@Test(dataProvider="sendData")
	public void verifyLoginFunctality(String cname, String fname, String lname, String phno) throws Exception {

		LoginPage lp = new LoginPage();
		lp.enterUsername().enterPassword().clickLogin().verifyLogin().clickCRMSFA().clickLeads().clickCreateLead()
				.enterCompanyName(cname).enterFirstName(fname).enterLastName(lname).clickCreate().verifyViewLead();

	}

}
