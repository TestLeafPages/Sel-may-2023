package testcase;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class VerifyLogin extends ProjectSpecificMethod {

	@BeforeTest
	public void setValues() {
		testName="Login Testcase";
		testDesc="Login with positive Credentials";
		author="Nitesh";
		category="Smoke";		
	}
	
	
	
	
	@Test
	public void verifyLoginFunctality() throws Exception {

		LoginPage lp = new LoginPage();
		/*
		 * lp.enterUsername(); lp.enterPassword(); lp.clickLogin();
		 * 
		 * 
		 * WelcomePage wp=new WelcomePage(); wp.clickCRMSFA();
		 */

		lp.enterUsername().enterPassword().clickLogin().verifyLogin();

	}

}
