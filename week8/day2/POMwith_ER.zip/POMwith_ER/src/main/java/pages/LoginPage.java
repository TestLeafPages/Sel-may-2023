package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethod {
	
	/*
	 * public LoginPage(RemoteWebDriver driver) { this.driver=driver; }
	 */

	@Given("Enter the username")
	public LoginPage enterUsername() throws Exception {
		try {
        getDriver().findElement(By.id("username")).sendKeys(prop.getProperty("username"));
		reportStep("Username is entered successfully","pass");
		}catch(Exception e) {
		reportStep("Username is not entered successfully " + e,"fail");
		}
		return this;
	}

	@Given("Enter the password")
	public LoginPage enterPassword() throws Exception {
		try {
		getDriver().findElement(By.id("password")).sendKeys(prop.getProperty("password"));
		reportStep("Password is entered successfully","pass");
		}catch(Exception e) {
			reportStep("Password is not entered successfully " +e,"fail");

		}
		return this;
	}

	@When("Click the Login")
	public WelcomePage clickLogin() throws Exception {
		try {
		getDriver().findElement(By.className("decorativeSubmit")).click();
		reportStep("Login button is clicked successfully","pass");

		}catch(Exception e) {
			reportStep("Login button is not clicked successfully " +e,"fail");

		}
		return new WelcomePage();
	}

}
