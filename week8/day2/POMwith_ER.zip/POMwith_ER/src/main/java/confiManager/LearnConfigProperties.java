package confiManager;

public class LearnConfigProperties {

	public static void main(String[] args) {
		System.out.println(ConfigurationManager.configuration().getUrl());
		System.out.println(ConfigurationManager.configuration().timeOut());

	}

}
